package com.kosmo.csi.board.service;

import java.util.ArrayList;

import com.kosmo.csi.board.dao.CsiBoardDAO;
import com.kosmo.csi.board.dao.CsiBoardDAOImpl;
import com.kosmo.csi.board.vo.CsiBoardVO;


public class CsiBoardServiceImpl implements CsiBoardService {

	@Override
	public ArrayList<CsiBoardVO> cboardSelectAll() {
		
		System.out.println("CsiBoardServiceImpl cboardSelectAll() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardSelectAll();
	}

	@Override
	public ArrayList<CsiBoardVO> cboardSelect(CsiBoardVO cvo) {
		
		System.out.println("CsiBoardServiceImpl cboardSelect() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardSelect(cvo);
	}

	@Override
	public int cboardInsert(CsiBoardVO cvo) {
		
		System.out.println("CsiBoardServiceImpl cboardInsert() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardInsert(cvo);
	}

	@Override
	public int cboardUpdate(CsiBoardVO cvo) {
		
		System.out.println("CsiBoardServiceImpl cboardUpdate() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardUpdate(cvo);
	}

	@Override
	public int cboardDelete(CsiBoardVO cvo) {
		
		System.out.println("CsiBoardServiceImpl cboardDelete() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardDelete(cvo);
	}

	@Override
	public ArrayList<CsiBoardVO> cboardSelectSubject(CsiBoardVO cvo) {
		
		System.out.println("CsiBoardServiceImpl cboardSelectSubject() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardSelectSubject(cvo);
	}

	@Override
	public ArrayList<CsiBoardVO> cboardSelectWriter(CsiBoardVO cvo) {
		
		System.out.println("CsiBoardServiceImpl cboardSelectWriter() �Լ� ���� >>> : ");
		
		CsiBoardDAO cdao = new CsiBoardDAOImpl();		
		return cdao.cboardSelectWriter(cvo);
	}
}
