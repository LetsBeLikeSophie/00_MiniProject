package com.kosmo.csi.login.service;

import com.kosmo.csi.member.vo.CsiMemberVO;

public interface CsiLoginService {

	public int cLoginCheck(CsiMemberVO cvo);
}
