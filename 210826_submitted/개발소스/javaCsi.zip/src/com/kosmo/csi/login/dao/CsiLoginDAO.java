package com.kosmo.csi.login.dao;

import com.kosmo.csi.member.vo.CsiMemberVO;

public interface CsiLoginDAO {

	public int cLoginCheck(CsiMemberVO cvo);
}


