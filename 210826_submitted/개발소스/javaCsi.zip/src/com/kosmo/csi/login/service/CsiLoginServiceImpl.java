package com.kosmo.csi.login.service;

import com.kosmo.csi.login.dao.CsiLoginDAO;
import com.kosmo.csi.login.dao.CsiLoginDAOImpl;
import com.kosmo.csi.member.vo.CsiMemberVO;

public class CsiLoginServiceImpl implements CsiLoginService {

	@Override
	public int cLoginCheck(CsiMemberVO cvo) {
		
		System.out.println("CsiLoginServiceImpl.hLoginCheck() �Լ� ���� ");
		
		CsiLoginDAO cdao = new CsiLoginDAOImpl();
		return cdao.cLoginCheck(cvo);		
	}
}
